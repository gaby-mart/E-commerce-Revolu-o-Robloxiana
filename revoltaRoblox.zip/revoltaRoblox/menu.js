let button = document.getElementById('btn-menu');

button.addEventListener('click', () => {
    button.classList.toggle('ativo')
});